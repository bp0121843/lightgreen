DO NOT modify the contents of following files:
  
bootstrap.css  

bootstrap.min.css

bootstrap.js   

contact_me.js 
 
jquery.js

bootstrap.min.js 

jqBootstrapValidation.js
